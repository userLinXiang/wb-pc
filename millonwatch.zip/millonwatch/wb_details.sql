CREATE TABLE wb_details (
    id INT PRIMARY KEY AUTO_INCREMENT,
    pic VARCHAR(128),
    big_pic VARCHAR(128),
    brand VARCHAR(36);
    brand_title VARCHAR(128),
    title VARCHAR(256),
    subtitle VARCHAR(256),
    property VARCHAR(256),
    num VARCHAR(128),
    pid INT,
    sales INT,
    price DECIMAL(10,2),
    old_price DECIMAL(10,2),
    details_head_img VARCHAR(128),
    details_body_img VARCHAR(128)
)AUTO_INCREMENT=1;
INSERT INTO wb_details VALUES(NULL,"img/details_md1.png","img/details_lg_1.png","天梭","【天梭原装正品，全球联保两年】天梭TISSOT-力洛克系列T006.407.11.033.00 自动机械男表","【天梭原装正品，全球联保两年】天梭TISSOT-力洛克系列T006.407.11.033.00 自动机械男表","机芯稳定性、精度、动力储存全面提升 力洛克T41.1.483.33全新升级版","","T006.407.11.033.00",62520,"3758",3420,4600,"img/details_head.jpg","img/details_body.jpg");

INSERT INTO wb_details VALUES(NULL,"img/details_md2.png","img/details_lg_2.png","劳力士","劳力士ROLEX-蚝式恒动系列 116231-63201黑色纪念花纹10钻 机械男表","劳力士ROLEX-蚝式恒动系列 116231-63201黑色纪念花纹10钻 机械男表","独道品味、耀眼风采与光芒","","116231-63201黑色纪念花纹10钻",11261,119,90450,100500,"img/details_head.jpg","img/details_body.jpg");

INSERT INTO wb_details VALUES(NULL,"img/details_md3.png","img/details_lg_3.png","天梭","天梭TISSO-杜鲁尔系列 T099.207.16.118.00 自动机械女表","天梭TISSO-杜鲁尔系列 T099.207.16.118.00 自动机械女表","","","T099.207.16.118.00",53048,363,4260,5600,"img/details_head.jpg","img/details_body.jpg");
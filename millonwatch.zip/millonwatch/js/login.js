//函数封装
function $(id) {
    document.getElementById(id);
}

//封装ajax判断浏览器是否支持
function createXhr() {
    var xhr=null;
    if(window.XMLHttpRequest){
        xhr=new XMLHttpRequest();
    }else{
        xhr=new ActiveXObject('Microsoft.XMLHttp');
    }
    return xhr;
}

function login() {
    //创建ajax对象
    var xhr=createXhr();
//    绑定监听事件
    xhr.onreadystatechange=function () {
        if(xhr.readyState==4&&xhr.status==200){
            var res=xhr.responseText;
            alert(res);
        }
    }
//    打开连接
    xhr.open('post','/product/login',true);
//    设置消息头 获取输入框的值
    var uname=$('user_name').value;
    var upwd=$('user_pwd').value;
    var url='user_name'+uname+'user_pwd'+upwd;
//    发送请求
    xhr.send(url);
}

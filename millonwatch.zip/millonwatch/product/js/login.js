$(function(){
    function login(){
    var uname=$("#uname").val();
    var upwd=$("#upwd").val();
    $.ajax({
        url:"http://localhost:3000/user/signin",
        type:"post",
        data:{uname,upwd},
        dataType:"json",
        success: function(res) {
            if(res.ok==0){ 
                alert(res.msg);
                return;
            }
            else
            alert("登录成功,自动返回上一页!");
            if(location.search.indexOf("back=")!=-1){
                var back=location.search.slice(6);
                location.href=back;
            }else{
                location.href="http://localhost:3000/index.html"
            }
        }
    })
}
    $("#login").on("click",function(){
        login();
    });
    $(".Bimg_login").keydown(function(e){
        if(e.keyCode==13){
            login();
        }
    })
})
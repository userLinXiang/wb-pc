$(function(){
    var lid=location.search.split("=")[1];
    $.ajax({
        url:"http://localhost:3000/details/getDetails",
        type:"get",
        data:{lid},
        dataType:"json",
        success: function(res) {
           //console.log(res);
           var {brand,brand_title,id}=res.product[0];
           var html=`<a href="">首页</a>
           <a href="">&gt;</a>
           <a href="">${brand}</a>
           <a href="">&gt;</a>
           <a href="">${brand_title}</a>`;
           $(".nav-tabbar-left").html(html);
           
           var {pic}=res.product[0];
           $(".md-img").html(`<img src='${pic}'>`);
           $(".x-img").html(`<img src='${pic}'>`);
           var {title,subtitle,num,pid,sales}=res.product[0];
           var html=`
           <div class="product-title">
                        ${title}
                    </div>
                    <div class="product-subtitle">
                        ${subtitle} 
                        <a href="">了解更多&gt;&gt;</a>
                    </div>
                    <div class="product-spec">
                        <div class="sepc-a">
                            <span>型号：</span>
                            <span>${num}</span>
                        </div>
                        <div class="sepc-b">
                            <span>编号：</span>
                            <span>${pid}</span>
                        </div>
                        <div class="spec-c">
                            <span>品牌：</span>
                            <span>天梭</span>
                        </div>
                        <div class="spec-d">
                            <span>销量：</span>
                            <span>${sales}</span>
                        </div>`;
            $(".head-details").html(html);
            var {price,old_price}=res.product[0];
            var html=`<div class="price-count clearfix">
            <div class="wb-price">万表价</div>
            <div class="wb-price-now">
                <span class="now-a">￥${price}</span>
                <span class="now-b">一口价</span>
                <span class="now-c">￥${old_price}</span>
            </div>
        </div>
        <div class="price-stage">
            <div class="stages-name">分期</div>
            <div class="stages-chance">
                <span class="stages-price">每月<span class="js-stages">${(old_price/12).toFixed (2)}</span>元×12期</span>
            </div>
            <span class="stages-free">
                    (免息免手续费)
            </span>
        </div>`;
        $(".product-price").html(html);
        var html=``;
        //console.log(res.product);
        if(res.spec!=undefined){
        for(var i=0;i<res.spec.length;i++){
            //console.log(p)
            console.log(res.spec[i]);
            var id=location.search.split("=")[1];
            var {spec,sm_pic,lid}=res.spec[i];
            html+=`<li class="${id==lid?'active':''}">
            <a href="product_details.html?lid=${lid}">
                <span class="s-img"><img src="${sm_pic}" alt=""></span>
                <span class="s-spec">${spec}</span>
            </a>
        </li>`
        }
        $(".servise-d-content>ul").html(html);
    }
        var {details_head_img,details_body_img}=res.product[0];
        $(".show-head-img").html(`<img src='${details_head_img}'>`);
        $(".show-body-img").html(`<img src='${details_body_img}'>`);
    }
    })
    function islogin(){
        $.ajax({
            url:"http://localhost:3000/user/islogin",
            type:"get",
            dataType:"json",
            success:function(res){
                if(res.ok==0){
                    $(".nologin").show()
                    .next().hide()
                }else if(res.ok==1){
                    $(".nologin").hide()
                    .next().show()
                    $(".islogin .pt_top_a2").html("Welcome:"+res.uname)
                }
            }
        })
    }
    islogin();
    
    //给注销按钮绑定signout事件
    $(".islogin").children(".pt_top_a1").on("click",function(e){
        //e.preventDefault();
        $.ajax({
            url:"http://localhost:3000/user/signout",
            type:"get",
            success:islogin()
        })
    })

    //给请登录绑定跳转事件
    $(".nologin").children(".pt_top_a1").on("click",function(e){
        e.preventDefault();
        location.href="login.html?back="+location.href;
        //console.log(location.href);
    })
})
$(function(){
    $("<link rel='stylesheet' href='css/header.css'>").appendTo("head")
    $.ajax({
        url:"http://localhost:3000/header.html",
        type:"get",
        success: function(res) {
            $("#header").replaceWith(res);

            //判断是否登录  来决定 islogin nologin 的display的属性
            function islogin(){
                $.ajax({
                    url:"http://localhost:3000/user/islogin",
                    type:"get",
                    dataType:"json",
                    success:function(res){
                        if(res.ok==0){
                            $(".nologin").show()
                            .next().hide()
                        }else if(res.ok==1){
                            $(".nologin").hide()
                            .next().show()
                            $(".islogin .pt_top_a2").html("Welcome:"+res.uname)
                        }
                    }
                })
            }
            islogin();
            
            //给注销按钮绑定signout事件
            $(".islogin").children(".pt_top_a1").on("click",function(e){
                //e.preventDefault();
                $.ajax({
                    url:"http://localhost:3000/user/signout",
                    type:"get",
                    success:islogin()
                })
            })

            //给请登录绑定跳转事件
            $(".nologin").children(".pt_top_a1").on("click",function(e){
                e.preventDefault();
                location.href="login.html?back="+location.href;
                //console.log(location.href);
            })

            //找到搜索的input框的内容 并找到搜索按钮绑定搜索 传递关键词到shopping页面
            var $input=$("input.head_search");
            $input.next().on("click",function(){
                var kw=$input.val().trim();
                if(kw!=""){
                    location.href="shopping.html?kword="+kw;
                }else{
                    location.href="shopping.html?kword=天梭";
                }
            })
            $input.keyup(function(e){
                if(e.keyCode==13){
                    $input.next().click();
                }
            })
            //考虑到编码问题 可以拿出kword后面的值 进行解码 重新赋值
            var kw="";
            if(location.search.indexOf("kword")!=-1){
                //console.log("哈哈");
                var kw=decodeURI(location.search.split("=")[1]);
            }
            $input.val(kw);
        }
    })
})
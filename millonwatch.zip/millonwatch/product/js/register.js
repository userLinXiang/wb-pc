$(function(){
    $("#uname").on("focus",function(){
        $("span.s1").html('请输入您的用户名');
    })
    $("#uname").on("blur",function(){
        var uname=$("#uname").val();
        //console.log(uname=="");
        if(uname==""){
            $("span.s1").html("用户名不能为空");
            return;
        }else{
        $.ajax({
            url:"http://localhost:3000/user/registerUname",
            type:"post",
            data:{uname},
            dataType:"json",
            success: function(res) {
                var html=res.msg;
                $("span.s1").html(html);
            }
        })
    }
    return uname;
    })
    
    $("#upwd").on("focus",function(){
        $("span.s2").html("请输入您的密码")
    })
    $("#upwd").on("blur",function(){
        var upwd=$("#upwd").val();
        if(upwd==""){
            $("span.s2").html("密码不能为空");
            return;
        }else{
            $("span.s2").html("");
    }
    })

    $("#upwd2").on("blur",function(){
        var upwd=$("#upwd").val();
        var upwd2=$("#upwd2").val();
        if(upwd2==""){
            $("span.s3").html("密码不能为空");
            return;
        }
        if(upwd==upwd2){
            $("span.s3").html("两次密码输入一致")
        }else{
            $("span.s3").html("两次密码输入不一致")
        }
    })
    $("#email").on("focus",function(){
        $("span.s4").html("请输入您的邮箱");
    })
    $("#email").on("blur",function(){
        var email=$("#email").val();
        if(email==""){
            $("span.s4").html("邮箱不能为空");
        }else{
            $("span.s4").html("");
        }
    })
    $("#phone").on("focus",function(){
        $("span.s5").html("请输入您的手机号");
    })
    $("#phone").on("blur",function(){
        var phone=$("#phone").val();
        if(phone==""){
            $("span.s5").html("手机号不能为空");
        }else{
            $("span.s5").html("");
            $('#submit').removeAttr("disabled");
        }
    })
    function register(){
       var uname=$("#uname").val();
       var upwd=$("#upwd").val();
       var email=$("#email").val();
       var phone=$("#phone").val();
       $.ajax({
           url:"http://localhost:3000/user/register",
           type:"post",
           data:{uname,upwd,email,phone},
           dataType:"json",
           success:function(res){
                return res;
           }
       }) 
    }
    $("#submit").on("click",function(){
        register();
        alert("注册成功");
        location.href="http://localhost:3000/login.html";
    })
    $(".main_body").on("keyup",function(e){
        if(e.keyCode==13){
        register();
        alert("注册成功,正在跳转到登录页面···");
        location.href="http://localhost:3000/login.html";
    }
    })
})
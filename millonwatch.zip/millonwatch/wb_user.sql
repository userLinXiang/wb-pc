CREATE TABLE wb_user (
  uid  int(11) PRIMARY KEY AUTO_INCREMENT,
  uname varchar(32) DEFAULT NULL,
  upwd varchar(32) DEFAULT NULL,
  email varchar(64) DEFAULT NULL,
  phone varchar(16) DEFAULT NULL,
  avatar varchar(128) DEFAULT NULL,
  user_name varchar(32) DEFAULT NULL,
  gender int(11) DEFAULT NULL
)AUTO_INCREMENT=1;
CREATE TABLE wb_shopcart(
    id INT PRIMARY KEY AUTO_INCREMENT,
    price DECIMAL(10,2),
    pic VARCHAR(128),
    title VARCHAR(326),
    count INT,
    ischecked BOOLEAN
)AUTO_INCREMENT=1;
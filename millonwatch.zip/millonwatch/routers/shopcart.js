const express=require("express");
const pool=require("../pool")
var router=express.Router();
//创建通过lid到wb_product_details 拿price d_img title
router.get("/shopProduct",(req,res)=>{
    var lid=req.query.lid;
    var sql="select price,d_img,title from wb_product_details where lid=?";
    pool.query(sql,[lid],(err,result)=>{
        if(err) console.log(err);
        var price=result[0].price;
        var pic=result[0].d_img;
        var title=result[0].title;
        var sql="insert into wb_shopcart values(NULL,?,?,?,1,0)";
        return pool.query(sql,[price,pic,title],(err,result)=>{
            if(err) console.log(err);
            res.send({code:1,msg:"添加成功"})
        })
        //res.send(result);
    })
})

//加载购物车所有商品
router.get('/showProduct',(req,res)=>{
    var sql="select * from wb_shopcart";
    pool.query(sql,[],(err,result)=>{
        if(err) console.log(err);
        res.send(result);
    })
})
module.exports=router;
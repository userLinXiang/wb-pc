const express=require('express');
//导入连接池
var pool=require('../pool.js');
var router=express.Router();

//创建获取数据库product_details库中的数据
router.get("/getProduct",(req,res)=>{
    var kw=req.query.kw;
    var output={
        count:0,
        pageSize:12,
        pageCount:0,
        pno:req.query.pno,
        data:[]
    };
    console.log(kw);
    var kws=kw.split(" ");//[男表 劳力士 ...]
    //通过遍历kws中的关键词 来设置模糊查询
    kws.forEach((elem,i,arr)=>{
        arr[i]=`subtitle like '%${elem}%'`
    })
    var where=kws.join(" and ");
    //subtitle like '%男表%' and '%劳力士%'...
    var sql=`select * from wb_product_details where ${where}`;
    pool.query(sql,[],(err,result)=>{
        if(err) console.log(err);
        console.log(result);
        output.count=result.length;
        output.pageCount=Math.ceil(output.count/output.pageSize);
        output.data=result;
        sql+=` limit ?,?`;
        return pool.query(sql,[output.pageSize*output.pno,output.pageSize],(err,result)=>{
            if(err) console.log(err);
            output.data=result;
            res.send(output); 
        })
    })   
})
module.exports=router;
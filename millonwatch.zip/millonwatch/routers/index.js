const express=require('express');
//导入连接池
var pool=require('../pool.js');
var router=express.Router();

router.get('/getIndexProduct',(req,res)=>{
    var sql="SELECT * FROM wb_index_product";
    pool.query(sql,[],(err,result)=>{
        if(err) console.log(err);
        res.writeHead(200,{
            "Content-Type":"application/json;charset=utf-8",
            "Access-Control-Allow-Origin":"*"
        })
        res.write(JSON.stringify(result));
        res.end(); 
    })
})



module.exports=router;
const express=require('express');
//导入连接池
var pool=require('../pool.js');
var router=express.Router();
//创建登录路由
router.post('/login',(req,res)=>{
    var obj=req.body;
    var $user_name=obj.user_name;
    var $user_pwd=obj.user_pwd;
    if(!$user_name){
        res.send('用户名不能为空');
    }
    if(!$user_pwd){
        res.send('密码不能为空');
    }
    var sql='select * from wb_user where user_name=? and user_pwd=?';
    pool.query(sql,[$user_name,$user_pwd],(err,result)=>{
        if (err) throw err;
        if(result.length>0){
            res.send('登录成功');
        }else{
            res.send('用户名或密码错误');
        }
    })
})







module.exports=router;
const express=require('express');

//导入连接池
var pool=require('../pool.js');
var router=express.Router();
//创建登录路由
router.post('/signin',(req,res)=>{
    var uname=req.body.uname;
    var upwd=req.body.upwd;
    var sql="select * from wb_user where uname=? and upwd=?";
    pool.query(sql,[uname,upwd],(err,result)=>{
        if(err) console.log(err)
        if(result.length>0){
        res.writeHead(200,{
            "Content-Type":"application/json;charset=utf-8",
            "Access-Control-Allow-Origin":"*"
        });
        var user=result[0];
        console.log(user);
        req.session.uid=user.uid;
        res.write(JSON.stringify({
          ok:1
        }))
      }else{
        res.write(JSON.stringify({
          ok:0,
          msg:"用户名或密码错误！"
        }))
      }
      res.end();
    })
})
//创建是否登录路由  用来判断是否已登录
router.get('/islogin',(req,res)=>{
    //1.设置响应头
    //2.判断session_id 是否为空 为空则未登录 不为空则通过session_id=uid 从数据库拿出
    var uid=req.session.uid
    if(uid==null){
      res.write(JSON.stringify({ok:0}));
      res.end();
    }else{
      var sql="select * from wb_user where uid=?";
      pool.query(sql,[uid],(err,result)=>{
        if(err) console.log(err);
        res.write(JSON.stringify({ok:1,uname:result[0].uname}));
        res.end();
      })
    }
})

//创建注销路由
router.get("/signout",(req,res)=>{
    delete req.session.uid;
    console.log(req.session.uid);
    res.send();
})


//创建注册路由
router.post('/registerUname',(req,res)=>{
  var uname=req.body.uname;
  var sql="select * from wb_user where uname=?";
  pool.query(sql,[uname],(err,result)=>{
    if(err) console.log(err);
    //console.log(result);
    if(result.length>0){
      res.send({code:0,msg:"用户名已被占用"});
      return;
    }else{
      res.send({code:1,msg:"用户名可用"})
    }
  })
})

router.post("/register",(req,res)=>{
    var uname=req.body.uname;
    //console.log(uname);
    var upwd=req.body.upwd;
    var email=req.body.email;
    var phone=req.body.phone;
    var sql="INSERT INTO wb_user VALUES(NULL,?,?,?,?,'','','')";
    pool.query(sql,[uname,upwd,email,phone],(err,result)=>{
      if(err) console.log(err);
      console.log(result);
      res.send({code:1,msg:"注册成功"})
    })  
})




module.exports=router;
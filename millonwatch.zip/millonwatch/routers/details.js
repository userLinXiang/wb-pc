const express = require("express");
var pool =require("../pool");
var router =express.Router();

router.get("/getDetails",(req,res)=>{
    var id=req.query.lid;
    var sql="select * from wb_details where id=?";
    var output={};
    pool.query(sql,[id],(err,result)=>{
        if(err) console.log(err);
        output.product=result;
        var sql='select family_id from wb_product_details where lid=?';
        pool.query(sql,[id],(err,result)=>{
            if(err) console.log(err);
            //console.log(result[0].family_id);
            var fid=result[0].family_id;
            var sql='select spec,sm_pic,lid from wb_product_details where family_id=?';
            return pool.query(sql,[fid],(err,result)=>{
                if(err) console.log(err)
                //console.log(result);
                if(result[0].spec!="")
                    output.spec=result;
                res.writeHead(200,{
                        "Content-Type":"application/json;charset=utf-8",
                        "Access-Control-Allow-Origin":"*"
                    })
                    res.write(JSON.stringify(output));
                    res.end();
            })
        })
        
    })
})

module.exports=router;